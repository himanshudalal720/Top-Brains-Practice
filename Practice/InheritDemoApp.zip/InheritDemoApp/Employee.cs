Class Employee
{
    public Employee(int Empid,string Name, float salary)
    {
        this.EmployeeId = Empid;
        this.Name = Name;
        this.Salary = Salary;
        

    }
}