using System;
class Vehical
{
    protected double distance=0.0;
    protected double hour=0.0;
    protected double fuel=0.0;
    public Vehicle(double distsnce, double hour, double fuel)
    {
        this.distance=distance;
        this.hour=hour;
        this.fuel=fuel;
    }
    public void Average()
    {
        double average = 0.0;
    }
}