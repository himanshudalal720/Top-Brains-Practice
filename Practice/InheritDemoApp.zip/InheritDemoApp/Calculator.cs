Class Calculator
{
    Public int Add()
    {
        int num1=30;
        int num2=n;
        return num1+num2;

    }
    public int Add(string str1, string str2)
    
}