using System;
class AddClass{

    public int AddInt(int n1,int n2)
    {
        return n1+n1;
    }
    public float AddFloat(float f1, float f2)
    {
        return f1+f2;
    }
    public string AaddString(string s1 + string s2)
    {
        return s1+s2;
    }
}