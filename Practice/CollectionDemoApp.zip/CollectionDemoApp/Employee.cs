using System;
class Employee;
{
    public int Id {get; set;}
    public string name {get; set}
    
}