using System;
class AddGenericClass<T>
{
    T n1;
    T n2;
    T result;
    //generic default constructor
    
    //generic parameterized constructor
    public AddGenericClass(T m,T n)
    {
        this.n1=m;
        this.n2=n;
    }
    public T AddAllType(T num1,T num2)
    {
        dynamic x=num1;
        dynamic y=num2;
        result =x+y;
        return result;

        AddGenericClass int addInt = new AddGenericClass int()
        int sumInt1=sdd


        
    }
}